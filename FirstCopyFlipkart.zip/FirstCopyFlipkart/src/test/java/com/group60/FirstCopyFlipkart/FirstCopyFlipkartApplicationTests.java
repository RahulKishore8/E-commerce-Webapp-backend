package com.group60.FirstCopyFlipkart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstCopyFlipkartApplicationTests {

	@Test
	void contextLoads() {
	}

}
