package com.group60.FirstCopyFlipkart.appUser;

public enum Role {
    CUSTOMER,
    MANAGER,
    ADMIN
}
